//Underlying sketch is edited from my submission to Lab assignment 2, variables and other components added. 
let cometOneX = 50
let cometTwoX = 50


function setup() {
  createCanvas(400, 400);
 frameRate(30);
}

function draw() {
  
let lg = color(180,255,230);
  let fv = sqrt(25);
  
  background(40);
  colorMode(RGB,255,255,255,1);
  
   

//Stars
fill(255);
noStroke();
  ellipse(30,200,fv,fv);
  ellipse(50,300,5,5);
  ellipse(80,220,5,5);
  ellipse(150,100,5,5)
  ellipse(300,200,5,5);
  ellipse(350,50,5,5);
  ellipse(380,380,5,5);
  ellipse(219,269,5,5);
  ellipse(119,364,5,5);

//Flying Comets

  stroke("blue");
  strokeWeight(20);
  line(cometOneX,200,cometOneX -100 ,200);
  
  stroke("cyan");
  strokeWeight(12);
  line(cometOneX, 200, cometOneX - 90, 200);
  
  stroke(255);
  strokeWeight(5);
  line(cometOneX, 200, cometOneX - 80, 200);
  
//2
  stroke("lime");
  strokeWeight(15);
  line(cometTwoX -80 , 100, cometTwoX - 150, 100);
  
  stroke(lg);
  strokeWeight(10);
  line(cometTwoX -80, 100, cometTwoX - 140, 100);
  
  stroke(255);
  strokeWeight(4);
  line(cometTwoX - 80, 100, cometTwoX -120, 100);

  
  noStroke();
  fill(200);
    circle(cometOneX, 200, 30);
  fill(220)
    circle(cometTwoX - 80,100,20);

  
  
  cometOneX = frameCount % width
  cometTwoX = frameCount % width
  
  
  
  
//planet
  push();
  fill(90,20,100);
  noStroke();
    ellipse(70,70,60,60);

  strokeWeight(5);
  stroke(255);
  noFill();
  rotate(radians(10) );
    arc(82,60,65,16,radians(0), radians(180) );
  pop();
 
  

  

  
  

//Meteor trail 
  stroke("yellow");
  strokeWeight(40);
  line(pmouseX , pmouseY, mouseX, mouseY);
  
  stroke("orange");
  strokeWeight(30);
  line(pmouseX , pmouseY, mouseX, mouseY);
  
  stroke("red");
  strokeWeight(10);
  line(pmouseX, pmouseY, mouseX , mouseY);
  
  
//Meteor
  fill(100,60,80);
  strokeWeight(0);
  circle(mouseX,mouseY,50);
 
  
  
 
}












