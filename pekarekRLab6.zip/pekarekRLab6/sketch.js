let logs = [];
let logsLength
let logs2 = [];
let logs3 = [];
let frogX = [];
let frogY = [];
let num = 5
function setup() {
  createCanvas(400, 400);

// first row  
  for (let i = 0; i < 20; i++) {
		logs[i] = random(-2000, 200); 
	}
  logsLength = random(80, 120);
  console.log(logs);

// second row  
  for (let i = 0; i < 20; i++) {
		logs2[i] = random(-2000, 200); 
	}
  
//third row  
  for (let i = 0; i < 20; i++) {
		logs3[i] = random(-2000, 200); 
	}
  
  	for (let p = 0; p < num; p++) {
      frogX[p] = 0;
      frogY[p] = 0;
	}
}

function draw() {
  background("lime");
fill("blue");
  rect(0,50,400,60);
  rect(0,150,400,60);
  rect(0,250,500,60);

//first row  
  for (let i = 0; i < logs.length; i++) {
		logs[i] +=0.5;	
    fill("brown");
     rect(logs[i], 65, logsLength , 30)
	}
  
//second row  
  for (let i = 0; i < logs2.length; i++) {
		logs2[i] +=0.5;	
    fill("brown");
     rect(logs2[i], 165, logsLength , 30);
	}  

//third row  
  for (let i = 0; i < logs3.length; i++) {
		logs3[i] +=0.5;	
    fill("brown");
     rect(logs3[i], 265, logsLength , 30);
	}
  
  for (let p = num - 1; p > 0; p--) {

		frogX[p] = frogX[p-1];

		frogY[p] = frogY[p-1];
	}

	frogX[0] = mouseX; 

	frogY[0] = mouseY; 

	for (let p = 0; p < num; p++) {

		fill("green");

		   ellipse(frogX[p], frogY[p], 50, 60);
     
      fill(255);
          ellipse(frogX[p] -15, frogY[p] -30, 20, 20);
          ellipse(frogX[p] +15, frogY[p] -30, 20, 20);
      fill(0);
          ellipse(frogX[p] -15, frogY[p] -30, 10, 10);
          ellipse(frogX[p] +15, frogY[p] -30, 10, 10);
      ellipse(frogX[p] -5, frogY[p] -15, 2, 2);
      ellipse(frogX[p] +5, frogY[p] -15, 2, 2);
	}
}


