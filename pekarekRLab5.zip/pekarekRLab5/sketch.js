 function setup() {
  createCanvas(400, 400);
  background(220);
   noStroke();
  fill("brown");
  ellipse(200,200,200,200);
  ellipse(200,250,200,300);
  triangle(120,145,185,135,125,75);
  triangle(200,155,280,140,275,75);
  angleMode(DEGREES);
}
mouth = "yellow"
topBeak = "brown"
let r
let g
let b

function draw() {
  frameRate(10);
  
fill(255);
  

//idea for while loops comes from https://p5js.org/reference/p5/while/  -modified 
    r = random(50,255);  
  g = random(50,255); 
  b = random(50,255); 
  
  push();
  d = 80
  d2 = 80
  minSize = 5
  
   while (d > minSize) {
strokeWeight(1);
stroke(0);
    circle(150, 160, d);
    d -= random(15, 25);
    fill(r,g,b);
      
  }
  pop();
  
    push();
   while (d2 > minSize) {
strokeWeight(1);
stroke(0);
    circle(250, 160, d2);
    d2 -= random(15, 25);
    fill(r,g,b);
      
  }
  pop();  
  
  fill("yellow");
  triangle(175,200,225,200,200,250);
  
 fill(topBeak);
  triangle(175,200,225,200,200,150);
 fill(mouth);
  triangle(185,200,215,200,200,220);
  

  
  
  for (let x = 120; x <180; x+= 20){
    fill("yellow");
    ellipse(x,320,20,50);
  }
    for (let x2 = 240; x2 <300; x2+= 20){
    fill("yellow");
    ellipse(x2,320,20,50);
  }

  
  
  

}






function mousePressed() {
  mouth = "pink"
  topBeak = "yellow"
}
function mouseReleased() {
  mouth = "yellow"
  topBeak = "brown"
}

function keyPressed(){
  if (key ==='f'){
    fill("red");
    circle(135,210,20);
    circle(270,210,20);
      }
  else if (key === 'd'){
    fill("brown");
    circle(135,210,20);
    circle(270,210,20);
  }
}

